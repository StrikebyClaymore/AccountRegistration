﻿namespace Core.Scripts
{
    public enum EResponse
    {
        NoExist,
        Exist,
        RegOK,
    }
}