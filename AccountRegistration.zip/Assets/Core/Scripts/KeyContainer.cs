﻿using System;
using System.Collections.Generic;

namespace Core.Scripts
{
    [Serializable]
    public class KeyContainer
    {
        public List<KeyItem> Keys { get; set; }
    }
}